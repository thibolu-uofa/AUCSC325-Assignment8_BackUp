# Assignment 8 starter

```bash
npm install
npx playwright install chromium
npx playwright test example        # should print: 1 passed
```

Useful commands:

| Command | What it does |
|---|---|
| `npx playwright test` | Run all tests |
| `npx playwright test login` | Run the test files whose name contains "login" |
| `npx playwright test loading --repeat-each 20` | Run the same tests 20 times (Part 4) |
| `npx playwright test --ui` | Watch and debug tests step by step |
| `npx playwright codegen https://the-internet.herokuapp.com` | Record a test while you click (clue in Part 3) |
| `npx playwright show-report` | Open the HTML report of the last run |

Tests go in `tests/`, one file per example, named `<example>.spec.js`.
`tests/pages/LoginPage.js` is a ready-made Page Object for Form Authentication. `tests/login.example.js` shows how to use it.
