// How to use the LoginPage Page Object. This file is not run (it does not end in .spec.js).
// Copy it to tests/login.spec.js and write your own Form Authentication tests there.
const { test, expect } = require('@playwright/test');
const { LoginPage } = require('./pages/LoginPage');

test('a wrong password shows an error', async ({ page }) => {
  const login = new LoginPage(page);
  await login.goto();
  await login.login('tomsmith', 'not-the-password');
  await expect(login.flash).toContainText('Your password is invalid!');
});
