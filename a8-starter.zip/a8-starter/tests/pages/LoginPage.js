// Page Object for the Form Authentication example (/login).
// It holds the page's locators and actions in one place, so tests do not repeat them.
// If the page changes, fix it here, not in every test.
// Checks (expect) belong in your tests, not in this class.
class LoginPage {
  constructor(page) {
    this.page = page;
    this.username = page.getByLabel('Username');
    this.password = page.getByLabel('Password');
    this.loginButton = page.getByRole('button', { name: 'Login' });
    this.logoutLink = page.getByRole('link', { name: 'Logout' });
    this.flash = page.locator('#flash');           // the green or red message at the top
  }

  async goto() {
    await this.page.goto('/login');
  }

  async login(user, password) {
    await this.username.fill(user);
    await this.password.fill(password);
    await this.loginButton.click();
  }

  async logout() {
    await this.logoutLink.click();
  }
}

module.exports = { LoginPage };
