// Example test. Run it with:  npx playwright test example
// It should pass before you start Part 2.
const { test, expect } = require('@playwright/test');

test('home page links to the login page', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Welcome to the-internet' })).toBeVisible();

  await page.getByRole('link', { name: 'Form Authentication' }).click();

  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByRole('heading', { name: 'Login Page' })).toBeVisible();
});
